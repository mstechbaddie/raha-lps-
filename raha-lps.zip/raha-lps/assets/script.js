(function(){
  const k='ra_consent';
  function get(){try{return JSON.parse(localStorage.getItem(k)||'{}')}catch(e){return {}}}
  function set(obj){localStorage.setItem(k,JSON.stringify(obj))}
  function show(){var b=document.getElementById('ra-consent'); if(b) b.style.display='block'}
  function hide(){var b=document.getElementById('ra-consent'); if(b) b.style.display='none'}
  function apply(){const c=get(); window.dataLayer=window.dataLayer||[]; function gtag(){dataLayer.push(arguments)};
    // Default: denied until choice
    gtag('consent','default',{ad_storage:'denied',analytics_storage:'denied'});
    // Update from stored choice
    gtag('consent','update',{ad_storage:(c.marketing?'granted':'denied'),analytics_storage:(c.analytics?'granted':'denied')});
    // Load pixels only if marketing=true (none included by default in this free build)
  }
  document.addEventListener('DOMContentLoaded', function(){
    const c=get(); if(!('analytics' in c)){show()} else {apply()}
    var acc=document.getElementById('ra-accept'); if(acc){acc.onclick=function(){set({analytics:true,marketing:true,timestamp:Date.now(),locale:'en'});hide();apply()}};
    var rej=document.getElementById('ra-reject'); if(rej){rej.onclick=function(){set({analytics:true,marketing:false,timestamp:Date.now(),locale:'en'});hide();apply()}};
    // Measurement hooks (console logs)
    console.log('event:view_content',{page_type:window.pageType||'lp',lang:'en',geo:window.geo||''});
    var sm=document.getElementById('start-match'); if(sm){sm.onclick=function(){console.log('event:start_match')}};
    var wa=document.getElementById('wa-cta'); if(wa){wa.onclick=function(){console.log('event:wa_click',{href:wa.href})}};
  });
})();
