# Raha LPs (Free static site)

A minimal, free, static landing site with 6 pages, consent banner, WhatsApp CTAs (with UTMs), OG meta, and basic measurement hooks.

## Files
- assets/og-image.png (1200x630 og image)
- assets/style.css
- assets/script.js (consent banner + event logs)
- /en/therapy/.../index.html (6 pages)

## Publish to GitHub Pages (free)
1. Create a free GitHub account at https://github.com/join
2. New repo → name: `raha-lps` → Public → Create.
3. Upload the contents of this folder (keeping directory structure).
4. Repo Settings → Pages → Source: Deploy from branch → Branch: `main` → Save.
5. Live URL: `https://YOURNAME.github.io/raha-lps/`
6. Visit a page, e.g.: `https://YOURNAME.github.io/raha-lps/en/therapy/arabic-speaking-therapist/uae/dubai/`

## Notes
- Replace the WhatsApp number in each page’s `wa.me` link.
- If/when you run ads, paste TikTok/Google tag code into `assets/script.js` inside the consent checks (marketing=true).
- Add canonical/hreflang for AR once an Arabic homepage exists.
- For consent: localStorage key `ra_consent` stores `{analytics, marketing, timestamp, locale}`.

## Optional next steps
- Connect a custom domain later (free via GitHub Pages + your DNS).
- Add privacy/terms pages as separate HTML files with footer links.
- Replace therapist cards with real profiles and booking links.
